#
# Example shell file for starting PhoenixMiner.exe to mine ETC
#

# IMPORTANT: Replace the ETC address with your own ETC wallet address in the -wal option (Rig001 is the name of the rig)
./PhoenixMiner -pool ssl://eu1-etc.ethermine.org:5555 -wal 0x4b96A2B3129CeE730d649c26EbA9Fb54FA0a1Af8.Rig001 -coin etc
